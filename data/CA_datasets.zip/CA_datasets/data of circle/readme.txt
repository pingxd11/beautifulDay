Experimental Settings:
Three groups of comparison experiments were carried out to change the change ratio of reference location. In each group, 
three groups of experiments were conducted according to the change mode of business circle and random form. Each 
group of experiments was compared with the original reference location data.
Input data:
Real_reflocs: reference location, 22226 pieces of data obtained from check in data of real users of CA.
Gas: real Gas station data on CA. The data was modified to remove some abnormal data , 500 data
Ref_x %_circle_y: change x% in real_reflocs data, which is normally distributed around the center of y business circle.
Ref_x %_random: randomly change the x% data in the real_reflocs data.
Cand_100_X: generate candidate location data by population distribution randomly from some existing facilities, with 100 
pieces of data for each group.
Output results:
Result_ : results of the experiment.

Schematic diagram:
CBD_x_y:  change x% data to generate y business circles.
Rand_y: change x% data randomly.
Real_c_y: s change y% of data corresponding to real reference location.
Experimental results: < id of replaced facility, select candidate location id>
result data:
---------------------------------------------------------------------------------------------------------------                                  
	          CBD 1	      CBD  3	    random	     real                   cand
10%	      <521, 3487>	<521, 5526>	<693, 6633>	<516, 3487>	c1
30%	      <516, 2005>	<465, 2005>	<521, 2005>	<516, 6717>	c2
50%	      <693, 409>	<693, 691>	<358, 825>	<516, 422>	c3
----------------------------------------------------------------------------------------------------------------



     

